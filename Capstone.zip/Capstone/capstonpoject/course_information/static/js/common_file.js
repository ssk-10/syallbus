function Download_cis(course) {
    let current_record = JSON.parse(course);
    console.log(current_record);


    let url_path =  'units_view' ;

    swal.fire({
      title: 'Download PDF!',
      text: "Do you want to download?",
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Download!',
    }).then((result) => {
      if (result.value) {
        // Display the second SweetAlert
        let timerInterval;
        Swal.fire({
          title: 'Downloading...',
          html: 'Your file is being downloaded.<br>Please wait...',
          timer: 1000, // Adjust this time to match the download time
          timerProgressBar: true,
          didOpen: () => {
            Swal.showLoading();
            const b = Swal.getHtmlContainer()?.querySelector('b');
            if (b) {
              timerInterval = setInterval(() => {
                b.textContent = Swal.getTimerLeft();
              }, 100);
            } else {
              // If the <b> element is not found, try an alternative selector
              const altB = Swal.getHtmlContainer()?.querySelector('.swal-text b');
              if (altB) {
                timerInterval = setInterval(() => {
                  altB.textContent = Swal.getTimerLeft();
                }, 100);
              } else {
//                console.error("Failed to find 'b' element in SweetAlert.");
              }
            }
          },
          willClose: () => {
            clearInterval(timerInterval);
            // Proceed with the download after the second alert is closed
            $.post(url_path, {
              // 'download_staff_info': current_record['id'],
              'download_staff_auth': current_record['id'],
              'csrfmiddlewaretoken': $('input[name="csrfmiddlewaretoken"]').val()
            }, function (data, textStatus) {
              var blob = new Blob([data]);
              var link = document.createElement('a');
              link.href = window.URL.createObjectURL(blob);
              link.download = 'course_info.pdf';
              document.body.append(link);
              link.click();
              link.remove();
              window.URL.revokeObjectURL(link);
            });
          },
        });
      }
    });
  }

