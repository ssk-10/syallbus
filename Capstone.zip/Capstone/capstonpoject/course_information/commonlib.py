from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa

class Commenlib:
    def __init__(self):
        self.DEFAULT_REDIRECT_PATH={'ROOT':'/'}

    @staticmethod
    def render(path: str, params: dict):
        template = get_template(path)
        html = template.render(params).encode('utf-8')  # Ensure html is a bytes object
        response = BytesIO()

        pisa.CreatePDF(html, dest=response)
        return HttpResponse(response.getvalue(), content_type='application/pdf')


