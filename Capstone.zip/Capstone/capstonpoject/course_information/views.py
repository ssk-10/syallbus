
from email.message import EmailMessage
from django.shortcuts import render, HttpResponse, redirect,HttpResponseRedirect
from django.views import View
from .forms import courseforms, syllabusform, syllabus_editform, unitform, unit_editform, \
    course_editforms, chapterform, chapters_editform, EmailForm

from .serializer import *
from django.utils import timezone
from django.contrib.auth.mixins import LoginRequiredMixin
from .commonlib import Commenlib
from django.db.models import Sum, Count

from django.contrib.auth import authenticate, login,logout
from django.core.mail import EmailMessage
from django.core.mail import send_mail
from django.contrib import messages

common_lib = Commenlib()


class Login(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self,request):
        username = request.POST['name']
        password = request.POST['pass']
        user = authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return HttpResponseRedirect('home')
        else:
            return HttpResponseRedirect('wrong password')


class logout_view(View):
    def get(self, request):
        logout(request)
        return HttpResponseRedirect('/')


class home_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self, request):
        return render(request, 'Home.html')

class index_cis(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self, req):
        return render(req, 'index_cis.html')


#Course information


class course_add(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer
    unit_serializers = UnitSerializer
    chapters_serializers = ChapterSerializer

    def get(self, request):
        return render(request, 'course.html')

    def post(self, request):
        course_code = request.POST['code']
        course_title = request.POST['title']
        con = str(request.POST['ltp'])
        cou = course.objects.filter(code__iexact=course_code)
        cou1 = course.objects.filter(title__iexact=course_title)
        if cou or cou1:
            a = "already exist"
            return render(request, 'course.html', {'msg': a})
        if len(con) == 3 and int(request.POST['ltp']) > 0:
            form = courseforms(request.POST, request.FILES)
            if form.is_valid():
                post_form = form.save(commit=False)
                post_form.ltp = "-".join(list(con))
                post_form.created = timezone.now()
                post_form.save()
                return redirect('course_view')
            else:
                return HttpResponse("<h1>FAIL</h1>")
        else:
            a = "enter correct ltp"
            return render(request, 'course.html', {'msg': a})


class course_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer

    def get(self, request):
        course_details = course.objects.all()
        course_records_serialized = self.course_serializers(course_details, many=True)
        context = {
            'course_details': course_records_serialized.data,

        }
        return render(request, 'course_view.html', context=context)


class activate_deactivate_course(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request, id):
        a_id=course.objects.get(id=id)
        status = a_id.status
        if status == 0:
            rename = 1
            course.objects.filter(id=id).update(status=rename)
            return redirect('course_view')
        elif status == 1:
            rename = 2
            course.objects.filter(id=id).update(status=rename)
            return redirect('course_view')
        else:
            rename = 0
            course.objects.filter(id=id).update(status=rename)
            return redirect('course_view')


class delete_course_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self, request,id):
        stud_id=course.objects.get(id=id)
        stud_id.delete()
        return redirect('course_view')


class edit_course_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer
    unit_serializers = UnitSerializer
    chapters_serializers = ChapterSerializer

    def get(self, request, id):
        stud_id = course.objects.get(id=id)
        serializer = courseSerializer(stud_id)
        form = course_editforms(instance=stud_id)
        stud_ltp = stud_id.ltp
        aa = int(stud_ltp.replace("-", ""))
        return render(request, 'edit_course.html', {'form': form, 'serializer': serializer.data, 'ltp': aa})

    def post(self, request, id):
        stud_id = course.objects.get(id=id)
        course_code = request.POST['code']
        course_title = request.POST['title']
        con = str(request.POST['ltp'])
        aa = int(stud_id.ltp.replace("-", ""))
        course_name = list(course.objects.all().values_list('title', flat=True))
        course_cod = list(course.objects.all().values_list('code', flat=True))
        course_name.remove(stud_id.title)
        course_cod.remove(stud_id.code)

        try:
            cou = course.objects.get(code__iexact=request.POST['code'], title__iexact=request.POST['title'])
            form = course_editforms(request.POST, instance=cou)
        except course.DoesNotExist:
            if any(name.lower() == course_title.lower() for name in course_name) or any(
                    name.lower() == course_code.lower() for name in course_cod):
                a = "Course already exist"
                form = course_editforms(instance=stud_id)
                return render(request, 'edit_course.html', {'msg': a, 'form': form, 'ltp': aa})
            form = course_editforms(request.POST, instance=stud_id)
        a = "enter valid ltp"
        if len(con) == 3 and int(request.POST['ltp']) > 0:
            if form.is_valid():
                post_form = form.save(commit=False)
                post_form.ltp = "-".join(list(con))
                post_form.updated = timezone.now()
                post_form.save()
                return redirect('course_view')
            return redirect('course_view')
        return render(request, 'edit_course.html', {'msg': a, 'form': form, 'ltp': aa})

        serializer = courseSerializer(stud_id)
        return render(request, 'update.html', {'form': form, 'course': serializer.data})


  # ===============================syllabus information=============================================

class syllabus_add(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer

    def get(self,request, id):
        c=course.objects.get(id=id)
        return render(request, 'syallabus.html', {'course': c})

    def post(self,request,id):
        form = syllabusform(request.POST,request.FILES)
        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.created = timezone.now()
            # post_form.user = user.username
            post_form.save()
            return redirect('syllabus_view')
        return HttpResponse("<h1>FAIL</h1>")


class syllabus_view(LoginRequiredMixin, View):
    syllabus_serial=syllabus_serializer
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request):

        syllabus_details=syllabus.objects.all()
        serial = self.syllabus_serial(syllabus_details,many=True,context={'request':request})
        serial_data=serial.data
        return render(request, 'syllabus_view.html', {'syllabus_details': syllabus_details,'context':serial_data})




class delete_syllabus_view(View):
    def get(self, request, id):
        stud_id=syllabus.objects.get(id=id)
        stud_id.delete()
        return redirect('syllabus_view')

class send_syllabus_view(View):
    def get(self, request, id):
        stud_id = syllabus.objects.get(id=id)
        return render(request, 'email_sent.html', {'stud_id': stud_id})

class edit_syllabus_view(View):
    def get(self,request, id):
        s_id = syllabus.objects.get(id=id)
        cc = s_id.course
        course_id = cc.id
        c = course.objects.get(id=course_id)
        form = syllabus_editform(instance=s_id)
        return render(request, 'edit_syllabus.html', {'form': form,'course': c})

    def post(self,request, id):
        s_id = syllabus.objects.get(id=id)
        form = syllabus_editform(request.POST, request.FILES, instance=s_id)
        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.updated = timezone.now()
            post_form.save()
            return redirect('syllabus_view')

        return redirect('syllabus_view')

#===================================================UNITS  INFORMATIONS===================================================================================


class units_add(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer
    unit_serializers = UnitSerializer

    def get(self, request, id):
        course_records = course.objects.filter(id=id)
        course_serializers_records = self.course_serializers(course_records,many=True)
        context = {
            'course_details': course_serializers_records.data,
        }
        return render(request, 'units.html', context=context)

    def post(self, request, id):
        course_records = course.objects.filter(id=id)
        course_serializers_records = self.course_serializers(course_records, many=True)
        unit_hour = float(request.POST['hour'])
        course_obj = course.objects.get(id=id)
        unitname_values = units.objects.filter(course=course_obj.id).values_list('unitname', flat=True)
        unit_code = request.POST['unitname'].lower()
        unit_hours = units.objects.filter(course=course_obj).aggregate(total_hours=Sum('hour'))

        if any(name.lower() == unit_code.lower() for name in unitname_values):
            context = {
                'course_details': course_serializers_records.data,
                'a': "Unit name already exists for this course.",
            }
            return render(request, 'units.html', context=context)

        if unit_hours['total_hours'] is not None:
            ad = unit_hours['total_hours'] + unit_hour
            if ad <= course_obj.duration:
                form = unitform(request.POST, request.FILES)
            else:
                context = {
                    'course_details': course_serializers_records.data,
                    'a': "Unit hours should be less than the course hours.",
                }
                return render(request, 'units.html', context=context)
        else:
            if unit_hour <= course_obj.duration:
                form = unitform(request.POST, request.FILES)
            else:
                context = {
                    'course_details': course_serializers_records.data,
                    'a': "Unit hours should be less than the course hours.",
                }
                return render(request, 'units.html', context=context)
        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.course = course_obj
            post_form.unitname = unit_code  # Assign the unit name from the request
            post_form.created = timezone.now()
            post_form.save()
            context = {
                'course_details': course_serializers_records.data,
                'b': "Successfully added the unit.",
            }
            return render(request, 'units.html', context=context)

        return HttpResponse("<h1>FAIL</h1>")


class units_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer
    unit_serializers = UnitSerializer
    chapters_serializers = ChapterSerializer

    def get(self, request):
        course_records = course.objects.all()
        unit = units.objects.all()
        course_records_serialized = self.course_serializers(course_records, many=True)

        course_list = []
        for course_element, course_item in enumerate(course_records_serialized.data):
            course_dict = {
                'id': course_item['id'],
                'title': course_item['title'],
                'code': course_item['code'],
                'duration': course_item['duration'],
                'ltp': course_item['ltp'],
                'credits': course_item['credits'],
                'contact': course_item['contact'],
                'isa': course_item['isa'],
                'esa': course_item['esa'],
                'tmarks': course_item['tmarks'],
                'teachinghrs': course_item['teachinghrs'],


            }

            unit_records = units.objects.filter(course=course_item['id']).order_by('unitname')
            unit_serializer = self.unit_serializers(unit_records, many=True)
            unit_list = []
            for unit_element, unit_item in enumerate(unit_serializer.data):
                unit_dict = {
                    'id': unit_item['id'],
                    'unitname': unit_item['unitname'],
                    'hour': unit_item['hour']
                }
                unit_list.append(unit_dict)
            course_dict['units'] = unit_list
            course_list.append(course_dict)

        context = {
            'unit_details': course_list,
            'units': unit

        }
        af=len(course_list)
        for i in range(0,af):
            if course_list[0]['id']==course_list[i]['id']:
                print("")
        return render(request, 'unit_view.html', context=context)

    def post(self, request):
        if 'download_staff_auth' in request.POST:
            print("valid",type(request.POST.get('download_staff_auth')))
            chapter_details = chapters.objects.filter(course=request.POST.get('download_staff_auth'))
            course_records = course.objects.all()
            course_records_serialized = self.course_serializers(course_records, many=True)
            course_list = []
            for course_element, course_item in enumerate(course_records_serialized.data):
                course_dict = {
                    'id': course_item['id'],
                    'title': course_item['title'],
                    'code': course_item['code'],
                    'duration': course_item['duration'],
                    'ltp': course_item['ltp'],
                    'credits': course_item['credits'],
                    'contact': course_item['contact'],
                    'isa': course_item['isa'],
                    'esa': course_item['esa'],
                    'tmarks': course_item['tmarks'],
                    'teachinghrs': course_item['teachinghrs'],

                }
                unit_records = units.objects.filter(course=course_item['id']).order_by('unitname')
                unit_serializer = self.unit_serializers(unit_records, many=True)
                unit_list = []
                for unit_element, unit_item in enumerate(unit_serializer.data):
                    unit_dict = {
                        'id': unit_item['id'],
                        'unitname': unit_item['unitname'],
                        'hour': unit_item['hour']
                    }

                    chapters_records = chapters.objects.filter(unit=unit_item['id'])
                    chapters_serializer = self.chapters_serializers(chapters_records, many=True)
                    chapters_list = []
                    for chapters_element, chapters_item in enumerate(chapters_serializer.data):
                        chapters_dict = {
                            'id': chapters_item['id'],
                            'cno': chapters_item['cno'],
                            'chapters': chapters_item['chapter_name'],
                            'content': chapters_item['content'],
                            'duration': chapters_item['duration']
                        }
                        chapters_list.append(chapters_dict)
                    unit_dict['chapters'] = chapters_list
                    unit_list.append(unit_dict)
                course_dict['units'] = unit_list
                course_list.append(course_dict)
            af = len(course_list)
            for i in range(0, af):
                if  int(request.POST.get('download_staff_auth'))== (course_list[i]['id']):
                    cc=course_list[i]
            chapter_det=self.chapters_serializers(chapter_details,many=True)
            context={
                'course': cc,
            }
            pdf_content = common_lib.render('unitdisplay.html', context)
            return HttpResponse(pdf_content,content_type='application/pdf')


class delete_units_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request,id):
        de_id = units.objects.get(id=id)
        de_id.delete()
        return redirect('units_view')


class edit_units_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request, id):
        s_id = units.objects.get(id=id)
        cc = s_id.course
        course_id = cc.id
        c = course.objects.get(id=course_id)
        form = unit_editform(instance=s_id)
        return render(request, 'edit_units.html', {'form': form, 'course': c})

    def post(self, request, id):
        one_unit_det = units.objects.get(id=id)
        cc = one_unit_det.course
        course_id = cc.id
        c = course.objects.get(id=course_id)
        one_course_det = course.objects.get(id=course_id)
        unit_name=request.POST['unitname']
        unit_hour=float(request.POST['hour'])
        u_name=list(units.objects.filter(course=request.POST['course']).values_list('unitname', flat=True))
        u_name.remove(one_unit_det.unitname)

        if any(name.lower() == request.POST['unitname'].lower() for name in u_name):
            context = {
                'a': "unitname already exist",
                'form': unit_editform(instance=one_unit_det),
                'course': c
            }
            return render(request, 'edit_units.html', context=context)
        else:
            form = unit_editform(request.POST, request.FILES, instance=one_unit_det)

        unit_hours = units.objects.filter(course=course_id).aggregate(total_hours=Sum('hour'))
        if unit_hours['total_hours'] is not None:
            ad = (float(unit_hours['total_hours'])-float(one_unit_det.hour)+unit_hour)
            if ad <= float(one_course_det.duration):
                form = unit_editform(request.POST, request.FILES, instance=one_unit_det)
            else:
                context = {
                    'a': "Unit hours should be less than the course hours.",
                    'form': unit_editform(instance=one_unit_det),
                    'course': c
                }
                return render(request, 'edit_units.html', context=context)

        else:
            if unit_hour <= float(one_course_det.duration):
                form = unit_editform(request.POST, request.FILES, instance=one_unit_det)
            else:
                context = {
                    'a': "Unit hours should be less than the course hours.",
                    'form': unit_editform(instance=one_unit_det),
                    'course': c
                }
                return render(request, 'edit_units.html', context=context)
        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.updated = timezone.now()
            post_form.save()
            return redirect('units_view')

        return HttpResponse('FAIL')


#==============================================CHAPTER INFORMATIONS====================================================
class chapter_add(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']
    course_serializers = courseSerializer
    unit_serializers = UnitSerializer
    chapters_serializers = ChapterSerializer

    def get(self, request, id, d_id):
        unit_records = units.objects.get(id=id)
        course_records = course.objects.get(id=d_id)
        unit_serializers_records = self.unit_serializers(unit_records, many=False)
        course_serializers_records = self.course_serializers(course_records, many=False)

        context = {
            'units_details': unit_serializers_records.data,
            'course_details': course_serializers_records.data
        }
        return render(request, 'chapters.html',context=context)

    def post(self, request, id, d_id):
        unit_records = units.objects.get(id=id)
        course_records = course.objects.get(id=d_id)
        chap = float(request.POST['duration'])
        chap_hours = chapters.objects.filter(unit=id,course=d_id).aggregate(total_hours=Sum('duration'))

        chaptername_values = list(chapters.objects.filter(unit=unit_records.id,course=course_records.id).values_list('chapter_name', flat=True))
        unit_serializers_records = self.unit_serializers(unit_records, many=False)
        course_serializers_records = self.course_serializers(course_records, many=False)
        chapter_no = int(request.POST['cno'])
        chapter_name = request.POST['chapter_name'].lower()
        check_cno = chapters.objects.filter(cno=chapter_no,unit=id,course=d_id)
        count_chap = chapters.objects.filter(unit=id,course=d_id).aggregate(total_chap=Count('cno'))
        chapp_cno=list(chapters.objects.filter(course=d_id).values_list('cno', flat=True))
        set_chap = set(chapp_cno)

        if any(name.lower() == chapter_name.lower() for name in chaptername_values) or check_cno:
            context = {
                'units_details': unit_serializers_records.data,
                'course_details': course_serializers_records.data,
                'unit': unit_records,
                'course': course_records,
                'a': "chapter name or chapter no is already exists for this unit."
            }
            return render(request, 'chapters.html', context=context)

        if count_chap['total_chap'] is not None:
            ad = count_chap['total_chap'] + 1
            if ad <= unit_records.chapter:
                form = chapterform(request.POST)
            else:
                context = {
                    'units_details': unit_serializers_records.data,
                    'course_details': course_serializers_records.data,
                    'unit': unit_records,
                    'course': course_records,
                    'a': "In this unit you can insert only " + str(count_chap['total_chap']) + " chapters."
                }
                return render(request, 'chapters.html', context=context)
        else:
            form = chapterform(request.POST)

        if chap_hours['total_hours'] is not None:
            ad = chap_hours['total_hours'] + chap
            if ad <= unit_records.hour:
                form = chapterform(request.POST)
            else:
                context = {
                    'units_details': unit_serializers_records.data,
                    'course_details': course_serializers_records.data,
                    'unit': unit_records,
                    'course': course_records,
                    'a': "chapter hours should be less than unit hours"
                }
                return render(request, 'chapters.html', context=context)
        else:
            if chap <= unit_records.hour:
                form = chapterform(request.POST)
            else:
                context = {
                    'units_details': unit_serializers_records.data,
                    'course_details': course_serializers_records.data,
                    'unit': unit_records,
                    'course': course_records,
                    'a': "chapter hours should be less than unit hours"
                }
                return render(request, 'chapters.html', context=context)
        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.created = timezone.now()
            post_form.save()
            context = {
                'units_details': unit_serializers_records.data,
                'course_details': course_serializers_records.data,
                'unit': unit_records,
                'course': course_records,
                'a': "Successfully Added the chapters"
            }
            return render(request, 'chapters.html', context=context)
        return HttpResponse("fail")


class newchapter_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request, u_id, c_id):
        if request.method == 'GET':
            course_details = course.objects.get(id=c_id)
            unit_details = units.objects.get(id=u_id)
            chapter_details = chapters.objects.filter(course=c_id, unit=u_id).order_by('cno')
        return render(request, 'Newchapter_view.html', {'chapter_details': chapter_details, 'course_name': course_details.title, 'unit_name': unit_details.unitname, 'unit_hour': unit_details.hour})


class delete_chapters_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self, request, id):
        de_id = chapters.objects.get(id=id)
        u_id=de_id.unit
        c_id=de_id.course
        course_name = de_id.course.title
        unit_name = de_id.unit.unitname
        chapter_details = chapters.objects.filter(course=c_id, unit=u_id).order_by('cno')
        de_id.delete()
        return render(request, 'Newchapter_view.html', {'chapter_details': chapter_details,'course_name':course_name,'unit_name':unit_name})


class edit_CHAPTERS_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self, request, id):
        chap = chapters.objects.get(id=id)
        cc = chap.course
        dd = chap.unit
        chapter_details = chapters.objects.filter(unit=dd)
        form = chapters_editform(instance=chap)
        return render(request, 'edit_chapters.html', {'form': form, 'course': cc, 'unit': dd})

    def post(self, request, id):
        chap = chapters.objects.get(id=id)
        cc = chap.course
        dd = chap.unit
        chapter_details = chapters.objects.filter(unit=dd)
        unit_det = chapters.objects.get(unit=dd,course=cc,id=id)
        chap_hour = float(request.POST['duration'])

        cno_name = list(chapters.objects.filter(course=request.POST['course'],unit=request.POST['unit']).values_list('cno', flat=True))
        c_name = list(chapters.objects.filter(course=request.POST['course'],unit=request.POST['unit']).values_list('chapter_name', flat=True))
        c_name.remove(chap.chapter_name)
        cno_name.remove(chap.cno)
        if any(name.lower() == request.POST['chapter_name'].lower() for name in c_name) or any(name == request.POST['cno'] for name in cno_name):
            context = {
                'a': "chapter already exist",
                'form': unit_editform(instance=chap),
                'course': cc,
                'unit': dd
            }
            return render(request, 'edit_chapters.html', context=context)
        else:
            form = chapters_editform(request.POST, request.FILES, instance=chap)

        chap_hours = chapters.objects.filter(course=request.POST['course'], unit=request.POST['unit']).aggregate(total_hours = Sum('duration'))
        if chap_hours['total_hours'] is not None:
            ad = (float(chap_hours['total_hours']) - float(chap.duration) + chap_hour)
            if ad <= float(unit_det.unit.hour):
                form = chapters_editform(instance=chap)
                form = chapters_editform(request.POST, request.FILES, instance=chap)
            else:
                return render(request, 'edit_chapters.html', {'form': form, 'course': cc, 'unit': dd, 'a': "chapter hour should less than the unit hour" })

        else:
            if chap_hour <= float(unit_det.hour):
                form = chapters_editform(request.POST, request.FILES, instance=chap)
            else:
                form = chapters_editform(instance=chap)
                return render(request, 'edit_chapters.html', {'form': form, 'course': cc, 'unit': dd, 'a':  "chapter hour should less than the unit hour"})

        if form.is_valid():
            post_form = form.save(commit=False)
            post_form.updated = timezone.now()
            post_form.save()
            return render(request, 'Newchapter_view.html', {'chapter_details': chapter_details,'course_name': cc.title ,'unit_name': dd.unitname})


class all_units_view(LoginRequiredMixin, View):
    login_url = common_lib.DEFAULT_REDIRECT_PATH['ROOT']

    def get(self,request, id):
        chapter_d = chapters.objects.filter(course=id).order_by('cno')
        unit_d = units.objects.filter(course=id).order_by('unitname')
        course_details = course.objects.get(id=id)
        context = {
            'chapter_details': chapter_d,
            'unit_details': unit_d,
            'course_name': course_details.title,
        }
        return render(request, 'unit_view_all.html', context=context)




class SendEmail(View):
    form_class = EmailForm
    def get(self, request):
        form = self.form_class()
        return render(request,'email_sent.html' , {'email_form': form})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST, request.FILES)

        if form.is_valid():
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            email = form.cleaned_data['email']
            file = request.FILES.getlist('attach')

            try:
                from django.conf import settings
                mail = EmailMessage(
                subject, message, settings.EMAIL_HOST_USER, [email])
                for f in file:
                    mail.attach(f.name, f.read(), f.content_type)
                mail.send()
                return redirect('success')
            except:
                return redirect('SendEmail')
        return HttpResponse('FAIL')

class success(View):
    def get(self, request):
        return render(request,'success.html')