from rest_framework import serializers
from rest_framework.fields import ReadOnlyField
from .models import *


class courseSerializer(serializers.ModelSerializer):
    class Meta:
        model = course
        fields = '__all__'

class UnitSerializer(serializers.ModelSerializer):
    course_id = ReadOnlyField(source='course.id')
    course_name = ReadOnlyField(source='course.title')
    course = serializers.SerializerMethodField()

    @staticmethod
    def get_course(obj):
        return obj.course.title

    class Meta:
        model = units
        fields = '__all__'

class ChapterSerializer(serializers.ModelSerializer):
    c_id = ReadOnlyField(source='course.id')
    u_id = ReadOnlyField(source='unit.id')
    unit_name = ReadOnlyField(source='unit.unitname')
    course = serializers.SerializerMethodField()
    unit = serializers.SerializerMethodField()

    @staticmethod
    def get_course(obj):
        return obj.course.title

    @staticmethod
    def get_unit(obj):
        return obj.unit.unitname

    class Meta:
        model = chapters
        fields = '__all__'

class syllabus_serializer(serializers.ModelSerializer):
    fname_url=serializers.SerializerMethodField()

    class Meta:
        model = syllabus
        fields = '__all__'
    def get_fname_url(self,obj):
        if obj.fname:
            return obj.fname.url
        return None