
from django.contrib import admin
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),

    path('',views.Login.as_view(),name="/"),

    path('home',views.home_view.as_view(),name="home_view"),

    path('success',views.success.as_view(),name="success"),


    path('index_cis/',views.index_cis.as_view(),name="index_cis"),
    path('logout/',views.logout_view.as_view(),name="logout"),


    path('sendemail/', views.SendEmail.as_view(), name='SendEmail'),


    path('course_add/',views.course_add.as_view(),name="course_add"),
    path('course_view/',views.course_view.as_view(),name="course_view"),
    path('delete_course_view/<int:id>/', views.delete_course_view.as_view(), name="delete_course_view"),
    path('send_syllabus_view/<int:id>/', views.send_syllabus_view.as_view(), name="send_syllabus_view"),

    path('edit_course_view/<int:id>/', views.edit_course_view.as_view(), name="edit_course_view"),
    path('activate/deactivate-view_course/<int:id>', views.activate_deactivate_course.as_view(),name="activate_deactivate_course"),


    path('syllabus/<int:id>/',views.syllabus_add.as_view(),name='syllabus_add'),
    path('syllabus_view/', views.syllabus_view.as_view(), name='syllabus_view'),
    path('delete_syllabus_view/<int:id>/',views.delete_syllabus_view.as_view(),name="delete_syllabus_view"),
    path('edit_syllabus_view/<int:id>/',views.edit_syllabus_view.as_view(),name="edit_syllabus_view"),


    path('units/<int:id>/', views.units_add.as_view(), name='units_add'),
    path('units_view', views.units_view.as_view(), name='units_view'),
    path('delete_units_view/<int:id>/',views.delete_units_view.as_view(),name="delete_units_view"),
    path('edit_units_view/<int:id>/',views.edit_units_view.as_view(),name="edit_units_view"),



    path('chapter/<int:id>/<int:d_id>', views.chapter_add.as_view() ,name='chapter_add'),
    path('newchapter_view/<int:u_id>/<int:c_id>/', views.newchapter_view.as_view(), name='newchapter_view'),
    path('delete_chapters_view/<int:id>/',views.delete_chapters_view.as_view(),name="delete_chapters_view"),
    path('edit_chapter_view/<int:id>/', views.edit_CHAPTERS_view.as_view(), name="edit_CHAPTERS_view"),

    path('unitall_view/<int:id>', views.all_units_view.as_view(), name="all_units_view"),

              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
