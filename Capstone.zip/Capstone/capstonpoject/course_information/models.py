
from django.db import models
from django.utils import timezone


# Create your models here.
class course(models.Model):
    code = models.CharField(max_length=20)
    title = models.CharField(max_length=255)
    description = models.TextField(max_length=2000, blank=True, null=True)
    status = models.IntegerField(default=0)
    user = models.CharField(max_length=255)
    created = models.DateTimeField(null=True,blank=True)
    updated = models.DateTimeField(default=timezone.now)
    duration = models.FloatField(default=0)
    ltp = models.CharField(max_length=500)
    credits = models.IntegerField(default=0)
    contact = models.FloatField(default=0)
    isa = models.IntegerField(default=0)
    esa = models.IntegerField(default=0)
    tmarks = models.IntegerField(default=0)
    teachinghrs = models.FloatField(default=0)
    author= models.CharField(max_length=255)






class syllabus(models.Model):
    course = models.ForeignKey(course, on_delete=models.CASCADE)
    fname = models.FileField(upload_to='files/')
    status = models.IntegerField(default=0)
    user = models.CharField(max_length=255, default="")
    created = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(default=timezone.now)


class units(models.Model):
    course = models.ForeignKey(course, on_delete=models.CASCADE)
    unitname = models.CharField(max_length=102, default="")
    chapter = models.IntegerField(default=0)
    hour = models.FloatField(default=0)
    user = models.CharField(max_length=255, default="")
    status = models.IntegerField(default=0)
    created = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(default=timezone.now)

class chapters(models.Model):
    course = models.ForeignKey(course, on_delete=models.CASCADE)
    unit = models.ForeignKey(units, on_delete=models.CASCADE)
    cno=models.IntegerField(default=0)
    chapter_name=models.CharField(max_length=100,default="")
    content=models.TextField(default=0)
    duration=models.FloatField(default=0)
    user = models.CharField(max_length=255, default="")
    status = models.IntegerField(default=0)
    created = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(default=timezone.now)