from django import forms
from .models import course, syllabus, units, chapters


class courseforms(forms.ModelForm):
    class Meta:
        model = course
        fields = ('code', 'title', 'description', 'duration', 'ltp', 'credits', 'contact', 'isa', 'esa',
                  'tmarks', 'teachinghrs', 'author')



class course_editforms(forms.ModelForm):
    class Meta:
        model = course
        fields = ('code', 'title', 'description', 'duration', 'ltp', 'credits', 'contact', 'isa', 'esa',
                  'tmarks', 'teachinghrs', 'author')


class syllabusform(forms.ModelForm):
    class Meta:
        model = syllabus
        fields = ('course', 'fname')


class syllabus_editform(forms.ModelForm):
    class Meta:
        model = syllabus
        fields = ('course', 'fname')


class unitform(forms.ModelForm):
    class Meta:
        model = units
        fields = ('course', 'unitname', 'hour', 'chapter')


class unit_editform(forms.ModelForm):
    class Meta:
        model = units
        fields = ('unitname', 'hour', 'chapter')


class chapterform(forms.ModelForm):
    class Meta:
        model = chapters
        fields = ('course', 'unit', 'cno', 'chapter_name', 'content', 'duration')


class chapters_editform(forms.ModelForm):
    class Meta:
        model = chapters
        fields = ('course', 'unit', 'cno', 'chapter_name', 'content', 'duration')



class EmailForm(forms.Form):
    email = forms.EmailField()
    subject = forms.CharField(max_length=100)
    attach = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}))
    message = forms.CharField(widget = forms.Textarea)
